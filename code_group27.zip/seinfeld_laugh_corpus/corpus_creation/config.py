import os

FFMPEG_PATH = os.path.join("external_tools", "ffmpeg", "bin")
SOX_PATH = os.path.join("external_tools", "sox")

# you must have a valid Opensubtitles User-Agent for subtitle downloading to work!
opensubtitles_credentials = {'user': 'user', 'password': 'password'}

